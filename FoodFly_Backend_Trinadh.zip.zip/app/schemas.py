from pydantic import BaseModel, EmailStr
from typing import List, Optional

# --- USER SCHEMAS ---
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str 
class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

# --- RESTAURANT SCHEMAS ---
class RestaurantCreate(BaseModel):
    name: str
    address: str

class RestaurantOut(BaseModel):
    id: int
    name: str
    address: str
    owner_id: int
    class Config:
        from_attributes = True

# --- MENU ITEM SCHEMAS ---
class MenuItemCreate(BaseModel):
    name: str
    price: float
    restaurant_id: int

class MenuItemOut(BaseModel):
    id: int
    name: str
    price: float
    restaurant_id: int
    class Config:
        from_attributes = True

# --- ORDER SCHEMAS ---
class OrderItemCreate(BaseModel):
    menu_item_id: int
    quantity: int

class OrderCreate(BaseModel):
    restaurant_id: int
    items: List[OrderItemCreate]

class OrderOut(BaseModel):
    id: int
    customer_id: int
    restaurant_id: int
    total_amount: float
    status: str
    class Config:
        from_attributes = True