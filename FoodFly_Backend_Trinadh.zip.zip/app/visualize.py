import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from sqlalchemy import create_engine

# 1. Database Connection (Ikkada nee password correct ga ivvu)
# Password daggara nee MySQL password pettu
engine = create_engine("mysql+pymysql://root:Trinadh@444@localhost/foodfly")

def generate_report():
    print("Generating Basic Analytics Report...")
    
    # Dummy Data (If DB is empty)
    data_reviews = {
        'restaurant_name': ['Dhaba Style', 'Alpha Hotel', 'Paradise', 'Dhaba Style', 'Alpha Hotel'],
        'rating': [5, 4, 3, 5, 2]
    }
    data_deliveries = {
        'delivery_status': ['delivered', 'delivered', 'assigned', 'delivered', 'assigned'],
        'distance_km': [3.5, 18.5, 5.0, 2.0, 15.2]
    }

    df_rev = pd.DataFrame(data_reviews)
    df_del = pd.DataFrame(data_deliveries)

    sns.set_theme(style="whitegrid")
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    sns.barplot(x='restaurant_name', y='rating', data=df_rev, ax=axes[0], palette="viridis")
    axes[0].set_title("Average Ratings")

    sns.boxplot(x='delivery_status', y='distance_km', data=df_del, ax=axes[1], palette="Set2")
    axes[1].set_title("Delivery Distance Analysis")

    plt.savefig("analytics_output.png")
    print("Success! 'analytics_output.png' saved.")
    plt.show()

def show_advanced_analytics():
    print("Generating Peak Hours & Rankings...")
    try:
        # A. Peak Order Hours logic
        query_peak = "SELECT HOUR(created_at) as hour, COUNT(*) as count FROM orders GROUP BY hour"
        df_peak = pd.read_sql(query_peak, engine)
        
        # B. Best Restaurant Ranking logic
        query_rank = """
            SELECT r.name, AVG(rv.rating) as avg_rating 
            FROM reviews rv 
            JOIN restaurants r ON rv.restaurant_id = r.id 
            GROUP BY r.name ORDER BY avg_rating DESC
        """
        df_rank = pd.read_sql(query_rank, engine)

        fig, axes = plt.subplots(1, 2, figsize=(16, 6))

        sns.lineplot(x='hour', y='count', data=df_peak, marker='o', ax=axes[0], color='red')
        axes[0].set_title("Peak Order Times (24-Hour Format)")

        sns.barplot(x='avg_rating', y='name', data=df_rank, ax=axes[1], palette="Blues_d")
        axes[1].set_title("Top Rated Restaurants")

        plt.tight_layout()
        plt.savefig("peak_and_rankings.png")
        print("Success! 'peak_and_rankings.png' saved.")
        plt.show()
    except Exception as e:
        print(f"Database Error: {e}. Make sure you have data in orders and reviews tables.")

if __name__ == "__main__":
    # Rendu functions ni call chesthunnam
    generate_report()
    show_advanced_analytics()