from fastapi import FastAPI, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from typing import List
from . import models, schemas, auth, database
from .database import engine, get_db
from .auth import get_current_user
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import func
from datetime import datetime
import os

# Limiter Imports
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi.responses import FileResponse

# 1. INITIALIZE APP & LIMITER
app = FastAPI(title="FoodFly - Full Delivery System")
@app.get("/")
def read_root():
    return {"message": "FoodFly Environment Ready!"}

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# 2. DATABASE TABLES CREATION
models.Base.metadata.create_all(bind=engine)

# --- MIDDLEWARE ---
@app.middleware("http")
async def simple_limit(request: Request, call_next):
    response = await call_next(request)
    return response

# --- 1. USER REGISTRATION & LOGIN ---
@app.post("/register", response_model=schemas.UserOut, tags=["Auth"])
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed_password = auth.get_password_hash(user.password)
    new_user = models.User(name=user.name, email=user.email, password=hashed_password, role=user.role)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@app.post("/login", response_model=schemas.Token, tags=["Auth"])
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == form_data.username).first()
    if not user or not auth.verify_password(form_data.password, user.password):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    
    access_token = auth.create_access_token(data={"sub": user.email, "role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}

# --- 2. RESTAURANTS ---
@app.post("/restaurants/", response_model=schemas.RestaurantOut, tags=["Business"])
def create_restaurant(restaurant: schemas.RestaurantCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if current_user.role != "owner":
        raise HTTPException(status_code=403, detail="Only owners can create restaurants")
    new_restaurant = models.Restaurant(**restaurant.dict(), owner_id=current_user.id)
    db.add(new_restaurant)
    db.commit()
    db.refresh(new_restaurant)
    return new_restaurant

# --- 3. MENU ITEMS ---
@app.post("/menu/", response_model=schemas.MenuItemOut, tags=["Business"])
def add_menu_item(item: schemas.MenuItemCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if current_user.role != "owner":
        raise HTTPException(status_code=403, detail="Only owners can add items")
    new_item = models.MenuItem(**item.dict())
    db.add(new_item)
    db.commit()
    db.refresh(new_item)
    return new_item

@app.get("/menu/{restaurant_id}", response_model=List[schemas.MenuItemOut], tags=["Business"])
def get_menu(restaurant_id: int, db: Session = Depends(get_db)):
    return db.query(models.MenuItem).filter(models.MenuItem.restaurant_id == restaurant_id).all()

# --- 4. ORDERS ---
@app.post("/orders/", response_model=schemas.OrderOut, tags=["Orders"])
def place_order(order_in: schemas.OrderCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if current_user.role != "customer":
        raise HTTPException(status_code=403, detail="Only customers can place orders")

    try:
        new_order = models.Order(
            customer_id=current_user.id,
            restaurant_id=order_in.restaurant_id,
            total_amount=0.0,
            status="pending"
        )
        db.add(new_order)
        db.flush()

        total_price = 0.0
        for item in order_in.items:
            menu_item = db.query(models.MenuItem).filter(models.MenuItem.id == item.menu_item_id).first()
            if menu_item:
                total_price += (menu_item.price * item.quantity)
                db_item = models.OrderItem(
                    order_id=new_order.id,
                    menu_item_id=item.menu_item_id,
                    quantity=item.quantity,
                    price=menu_item.price
                )
                db.add(db_item)
            else:
                raise HTTPException(status_code=404, detail=f"Item {item.menu_item_id} not found")

        new_order.total_amount = total_price
        db.commit()
        db.refresh(new_order)
        return new_order
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# --- 5. SMART ASSIGNMENT (WITH RATE LIMITER) ---
@app.post("/orders/{order_id}/calculate-and-assign", tags=["Delivery"])
@limiter.limit("5/minute")
def smart_assign(request: Request, order_id: int, db: Session = Depends(get_db)):
    order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    existing = db.query(models.Delivery).filter(models.Delivery.order_id == order_id).first()
    if existing:
        return {"message": "Already assigned", "delivery_id": existing.id}

    restaurant = db.query(models.Restaurant).filter(models.Restaurant.id == order.restaurant_id).first()
    vizag_map = {
        "Gajuwaka": {"MVP Colony": 18.5, "Siripuram": 17.0, "Gajuwaka": 1.0},
        "MVP Colony": {"Siripuram": 3.5, "Jagadamba": 5.2, "MVP Colony": 1.0},
        "Siripuram": {"Jagadamba": 2.0, "MVP Colony": 3.5, "Siripuram": 0.5}
    }
    res_area = restaurant.address if restaurant else "Siripuram"
    cust_area = getattr(order, 'delivery_address', 'MVP Colony')
    distance = vizag_map.get(res_area, {}).get(cust_area, 5.0)

    partner = db.query(models.User).filter(models.User.role == 'delivery').first()
    if not partner:
         raise HTTPException(status_code=404, detail="No partners available")

    new_delivery = models.Delivery(
        order_id=order.id, delivery_partner_id=partner.id,
        distance_km=distance, delivery_status="assigned"
    )
    order.status = "assigned"
    db.add(new_delivery)
    db.commit()
    return {"status": "Assigned", "partner": partner.name, "bill": 20 + (distance * 10)}

# --- 6. STATUS UPDATES ---
@app.put("/deliveries/{delivery_id}/pickup", tags=["Delivery"])
def pickup_order(delivery_id: int, db: Session = Depends(get_db)):
    delivery = db.query(models.Delivery).filter(models.Delivery.id == delivery_id).first()
    delivery.delivery_status = "picked_up"
    db.commit()
    return {"message": "Picked up"}

@app.put("/deliveries/{delivery_id}/complete", tags=["Delivery"])
def complete_order(delivery_id: int, db: Session = Depends(get_db)):
    delivery = db.query(models.Delivery).filter(models.Delivery.id == delivery_id).first()
    delivery.delivery_status = "delivered"
    order = db.query(models.Order).filter(models.Order.id == delivery.order_id).first()
    order.status = "delivered"
    db.commit()
    return {"message": "Delivered"}

# --- 7. ANALYTICS ---
@app.get("/admin/report", tags=["Analytics"])
def get_report():
    if os.path.exists("analytics_output.png"):
        return FileResponse("analytics_output.png")
    return {"error": "Run visualize.py first"}

@app.get("/analytics/{res_id}", tags=["Analytics"])
def get_res_analytics(res_id: int, db: Session = Depends(get_db)):
    count = db.query(models.Order).filter(models.Order.restaurant_id == res_id).count()
    return {"total_orders": count}
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=9000)