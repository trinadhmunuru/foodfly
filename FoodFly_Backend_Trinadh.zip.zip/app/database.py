from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import urllib.parse

# MySQL Password and Connection Settings
password = "Trinadh@444"
encoded_password = urllib.parse.quote_plus(password)

# Docker nundi connect avvadaniki 127.0.0.1 badulu host.docker.internal vadali
DATABASE_URL = f"mysql+pymysql://root:{encoded_password}@host.docker.internal:3306/foodfly_db"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()