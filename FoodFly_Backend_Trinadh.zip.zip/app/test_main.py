import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app

# 1. Pytest ki idi async code ani cheppali
pytestmark = pytest.mark.asyncio

@pytest.mark.asyncio
async def test_read_main():
    """Server run avthundho ledho basic check"""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/")
    assert response.status_code == 200

@pytest.mark.asyncio
async def test_smart_assign_logic():
    """Smart Assign endpoint connectivity check"""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        # Test order_id = 1
        response = await ac.post("/orders/1/calculate-and-assign")
    
    # Logic: Order DB lo unte 200 ravali, lekapothe 404 ravali. 
    # Kaani server crash avvakunda response isthe test success!
    assert response.status_code in [200, 404, 429] # 429 is for Rate Limit


