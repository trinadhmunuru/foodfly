from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Boolean, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base

# 1. Users Model
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    email = Column(String(100), unique=True, index=True)
    password = Column(String(255))
    role = Column(String(50))

# 2. Restaurant Model
class Restaurant(Base):
    __tablename__ = "restaurants"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    address = Column(String(255))
    owner_id = Column(Integer, ForeignKey("users.id"))
    rating = Column(Float, default=0)
    is_active = Column(Boolean, default=True)

    menu_items = relationship("MenuItem", back_populates="restaurant")

# 3. Menu Item Model
class MenuItem(Base):
    __tablename__ = "menu_items"
    id = Column(Integer, primary_key=True, index=True)
    restaurant_id = Column(Integer, ForeignKey("restaurants.id"))
    name = Column(String(100))
    price = Column(Float)
    description = Column(Text)
    category = Column(String(50))

    restaurant = relationship("Restaurant", back_populates="menu_items")

# 4. Order Model
class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("users.id"))
    restaurant_id = Column(Integer, ForeignKey("restaurants.id"))
    total_amount = Column(Float)
    status = Column(String(50), default="pending") 
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    delivery_address = Column(String(255))

    items = relationship("OrderItem", back_populates="order")
    delivery = relationship("Delivery", back_populates="order", uselist=False)

# 5. Order Item Model
class OrderItem(Base):
    __tablename__ = "order_items"
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"))
    menu_item_id = Column(Integer, ForeignKey("menu_items.id"))
    quantity = Column(Integer)
    price = Column(Float)

    order = relationship("Order", back_populates="items")

# --- Day 5: Delivery Model ---
class Delivery(Base):
    __tablename__ = "deliveries"
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), unique=True)
    delivery_partner_id = Column(Integer, ForeignKey("users.id"))
    
    distance_km = Column(Float, nullable=True) 
    
    delivery_status = Column(String(50), default="assigned")
    pickup_time = Column(DateTime, nullable=True)
    delivery_time = Column(DateTime, nullable=True)

    order = relationship("Order", back_populates="delivery")
# --- Day 6: Review Model ---
class Review(Base):
    __tablename__ = "reviews"
    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("users.id"))
    restaurant_id = Column(Integer, ForeignKey("restaurants.id"))
    rating = Column(Integer)
    comment = Column(Text)

# --- Day 7: Analytics Model ---
class AnalyticsLog(Base):
    __tablename__ = "analytics_logs"
    id = Column(Integer, primary_key=True, index=True)
    restaurant_id = Column(Integer, ForeignKey("restaurants.id"))
    total_orders = Column(Integer, default=0)
    avg_delivery_time_min = Column(Float, default=0)
    log_date = Column(DateTime, server_default=func.now())